import 'package:get/get.dart';

class FeedbackController extends GetxController {
  void submitFeedback(int rating, String feedback) {
    // Dummy feedback submission
    print('Feedback submitted: Rating: $rating, Feedback: $feedback');
    Get.snackbar('Success', 'Thank you for your feedback!');
  }
}
