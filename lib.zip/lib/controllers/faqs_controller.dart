import 'package:get/get.dart';

class FAQ {
  final String question;
  final String answer;

  FAQ({required this.question, required this.answer});
}

class FAQsController extends GetxController {
  var faqs = <FAQ>[].obs;

  @override
  void onInit() {
    super.onInit();
    faqs.addAll([
      FAQ(
        question: 'How do I reset my password?',
        answer: 'Go to Settings > Change Password and follow the instructions.',
      ),
      FAQ(
        question: 'How can I contact support?',
        answer: 'You can reach us through the feedback section or email support@campus.com',
      ),
      FAQ(
        question: 'Is my data secure?',
        answer: 'Yes, we use industry-standard encryption to protect your data.',
      ),
      FAQ(
        question: 'Can I delete my account?',
        answer: 'Yes, go to Settings > Account and select Delete Account.',
      ),
    ]);
  }
}
