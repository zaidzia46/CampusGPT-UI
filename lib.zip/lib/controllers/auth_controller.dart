import 'package:get/get.dart';

class AuthController extends GetxController {
  var isLoggedIn = false.obs;
  var currentUser = ''.obs;

  void login(String email, String password) {
    // Dummy login logic
    isLoggedIn.value = true;
    currentUser.value = email;
  }

  void signup(String name, String email, String password) {
    // Dummy signup logic
    isLoggedIn.value = true;
    currentUser.value = name;
  }

  void logout() {
    isLoggedIn.value = false;
    currentUser.value = '';
  }
}
