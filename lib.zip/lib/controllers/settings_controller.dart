import 'package:get/get.dart';

class SettingsController extends GetxController {
  var notificationsEnabled = true.obs;
  var language = 'English'.obs;

  void logout() {
    // Dummy logout logic
    print('User logged out');
  }

  void updateNotifications(bool value) {
    notificationsEnabled.value = value;
  }

  void changeLanguage(String lang) {
    language.value = lang;
  }
}
