import 'package:get/get.dart';

class ChatMessage {
  final String text;
  final bool isUser;

  ChatMessage({required this.text, required this.isUser});
}

class ChatController extends GetxController {
  var messages = <ChatMessage>[].obs;

  @override
  void onInit() {
    super.onInit();
    messages.add(ChatMessage(
      text: 'Hello! How can I help you today?',
      isUser: false,
    ));
  }

  void sendMessage(String text) {
    messages.add(ChatMessage(text: text, isUser: true));
    // Simulate AI response
    Future.delayed(const Duration(seconds: 1), () {
      messages.add(ChatMessage(
        text: 'Thanks for your question! I\'m here to help.',
        isUser: false,
      ));
    });
  }
}
