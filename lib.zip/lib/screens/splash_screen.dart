import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import '../widgets/starry_background.dart';
import 'onboarding_screen.dart';
import 'package:lottie/lottie.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(seconds: 3), () {
      Get.offAll(() => const OnboardingScreen());
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: StarryBackground(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 150,
                height: 150,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    colors: [const Color(0xFF7C3AED), const Color(0xFF06B6D4)],
                  ),
                ),
                child: Lottie.asset('assets/animation/splash_anim.json'),
              ),
              const SizedBox(height: 24),
              Text(
                'AI Campus Assistant',
                style: TextStyle(
                  fontSize: 28,
                  // fontWeight: FontWeight.w900,
                  color: Colors.white,
                  fontFamily: 'font2',
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Your Educational Guide',
                style: TextStyle(
                  fontSize: 14,
                  color: const Color(0xFFCBD5E1),
                  fontWeight: FontWeight.w300,
                  fontFamily: 'font1',
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
