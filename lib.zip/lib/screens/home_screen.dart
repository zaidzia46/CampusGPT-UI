import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:crystal_navigation_bar/crystal_navigation_bar.dart';
import 'package:google_fonts/google_fonts.dart';

import '../controllers/home_controller.dart';
import '../widgets/starry_background.dart';
import 'chat_screen.dart';
import 'events_screen.dart';
import 'faqs_screen.dart';
import 'feedback_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final HomeController homeController = Get.put(HomeController());
  int _selectedIndex = 0;

  final List<Widget> _screens = [
    const ChatScreen(),
    const EventsScreen(),
    const FAQsScreen(),
    const SettingsScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBody: true, // 🔮 Allows nav bar to float above background
      // drawer: _buildDrawer(context),
      body: StarryBackground(child: _screens[_selectedIndex]),

      // 💎 Crystal Navigation Bar
      bottomNavigationBar: CrystalNavigationBar(
        currentIndex: _selectedIndex,
        height: 65,
        backgroundColor: Colors.white.withOpacity(0.07), // glass blur effect
        outlineBorderColor: Colors.white.withOpacity(0.12),
        enableFloatingNavBar: true,
        borderRadius: 24,
        marginR: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
        unselectedItemColor: Colors.white70,
        selectedItemColor: const Color(0xFF06B6D4),
        onTap: (index) => setState(() => _selectedIndex = index),

        items: [
          CrystalNavigationBarItem(
            icon: Icons.chat_bubble,
            unselectedIcon: Icons.chat_bubble_outline,
          ),
          CrystalNavigationBarItem(
            icon: Icons.event,
            unselectedIcon: Icons.event_outlined,
          ),
          CrystalNavigationBarItem(
            icon: Icons.help,
            unselectedIcon: Icons.help_outline,
          ),
          CrystalNavigationBarItem(
            icon: Icons.settings,
            unselectedIcon: Icons.settings_outlined,
          ),
        ],
      ),
    );
  }

  // 🧭 Drawer (works with Crystal bar)
  // Drawer _buildDrawer(BuildContext context) {
  //   return Drawer(
  //     backgroundColor: const Color(0xFF0E0E10),
  //     child: ListView(
  //       padding: EdgeInsets.zero,
  //       children: [
  //         DrawerHeader(
  //           decoration: const BoxDecoration(
  //             gradient: LinearGradient(
  //               colors: [Color(0xFF7C3AED), Color(0xFF06B6D4)],
  //               begin: Alignment.topLeft,
  //               end: Alignment.bottomRight,
  //             ),
  //           ),
  //           child: Column(
  //             crossAxisAlignment: CrossAxisAlignment.start,
  //             children: [
  //               const CircleAvatar(radius: 28, backgroundColor: Colors.white),
  //               const SizedBox(height: 10),
  //               Text(
  //                 'AI Campus Companion',
  //                 style: GoogleFonts.poppins(
  //                   color: Colors.white,
  //                   fontWeight: FontWeight.bold,
  //                   fontSize: 16,
  //                 ),
  //               ),
  //               Text(
  //                 'Your smart university guide',
  //                 style: GoogleFonts.inter(color: Colors.white70, fontSize: 12),
  //               ),
  //             ],
  //           ),
  //         ),
  //         _buildDrawerItem(Icons.home, 'Home', 0),
  //         _buildDrawerItem(Icons.chat, 'Chat', 1),
  //         _buildDrawerItem(Icons.event, 'Events', 2),
  //         _buildDrawerItem(Icons.help, 'FAQs', 3),
  //         _buildDrawerItem(Icons.settings, 'Settings', 4),
  //         const Divider(color: Colors.white10),
  //         ListTile(
  //           leading: const Icon(Icons.logout, color: Colors.redAccent),
  //           title: Text(
  //             'Logout',
  //             style: GoogleFonts.inter(color: Colors.redAccent),
  //           ),
  //           onTap: () {},
  //         ),
  //       ],
  //     ),
  //   );
  // }

  // Widget _buildDrawerItem(IconData icon, String title, int index) {
  //   final bool selected = _selectedIndex == index;
  //   return ListTile(
  //     leading: Icon(icon, color: selected ? Colors.cyanAccent : Colors.white70),
  //     title: Text(
  //       title,
  //       style: GoogleFonts.inter(
  //         color: selected ? Colors.cyanAccent : Colors.white70,
  //       ),
  //     ),
  //     onTap: () {
  //       setState(() => _selectedIndex = index);
  //       Navigator.pop(context);
  //     },
  //   );
  // }
}

class HomeContent extends StatelessWidget {
  const HomeContent({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Welcome Back!',
                style: GoogleFonts.poppins(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Ready to learn something new today?',
                style: GoogleFonts.inter(
                  fontSize: 14,
                  color: const Color(0xFFCBD5E1),
                ),
              ),
              const SizedBox(height: 32),
              GridView.count(
                crossAxisCount: 2,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                mainAxisSpacing: 16,
                crossAxisSpacing: 16,
                children: [
                  _buildFeatureCard(
                    icon: Icons.chat,
                    title: 'AI Chat',
                    subtitle: 'Ask questions',
                    onTap: () => Get.to(() => const ChatScreen()),
                  ),
                  _buildFeatureCard(
                    icon: Icons.event,
                    title: 'Events',
                    subtitle: 'Campus events',
                    onTap: () => Get.to(() => const EventsScreen()),
                  ),
                  _buildFeatureCard(
                    icon: Icons.help,
                    title: 'FAQs',
                    subtitle: 'Get answers',
                    onTap: () => Get.to(() => const FAQsScreen()),
                  ),
                  _buildFeatureCard(
                    icon: Icons.feedback,
                    title: 'Feedback',
                    subtitle: 'Share thoughts',
                    onTap: () => Get.to(() => const FeedbackScreen()),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  static Widget _buildFeatureCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: const Color(0xFF1E293B),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: const Color(0xFF334155)),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 56,
              height: 56,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: const LinearGradient(
                  colors: [Color(0xFF7C3AED), Color(0xFF06B6D4)],
                ),
              ),
              child: Icon(icon, color: Colors.white, size: 28),
            ),
            const SizedBox(height: 12),
            Text(
              title,
              style: GoogleFonts.poppins(
                fontSize: 16,
                fontWeight: FontWeight.w600,
                color: Colors.white,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              subtitle,
              style: GoogleFonts.inter(
                fontSize: 12,
                color: const Color(0xFFCBD5E1),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
